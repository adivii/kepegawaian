function home_load(role){
    if(role == "admin"){
        document.getElementById("profile").style.display = "none";
        document.getElementById("add-hrd").style.display = "block";
    }else if(role == "calon"){
        document.getElementById("profile").style.display = "block";
        document.getElementById("add-hrd").style.display = "none";
    }
}